import pymysql

pymysql.install_as_MySQLdb()
pymysql.version_info = (1, 3, 13, 'final', 0)
